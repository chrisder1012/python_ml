Installation
------------

Install the graphviz library::
    
    sudo apt-get install graphviz

Install sphinx::

    sudo pip install sphinx

You might also need to install the Python graphviz interface::

    sudo pip install graphviz
