from distutils.core import setup

setup(
	name		='grasshopper',
	version		='1.1.3',
	py_modules	=['grasshopper'],
	author		='Frank AK',
	author_email='landpack@sina.com',
	url			='http://www.github.com/land-pack',
	description	='simple asyn-socket server for receiver GPS terminal data'
)
