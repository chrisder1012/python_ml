import stack_data
import inspect

frame_info = stack_data.FrameInfo(inspect.currentframe())
