class ParticlesUnderFlowError(Exception):
    """
    Custom exception for tell users if a subspace does not
    have enough particles.
    """
    pass
