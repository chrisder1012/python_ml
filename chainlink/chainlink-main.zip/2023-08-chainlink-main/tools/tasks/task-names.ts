export const TASK_ACCOUNTS: string = 'accounts';
