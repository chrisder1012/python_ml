# Security Policy

## Reporting a Vulnerability

All IPython and Jupyter security are handled via security@ipython.org.
You can find more information on the Jupyter website. https://jupyter.org/security

## Tidelift

We are also lifting IPython via Tidelift, you can also report security concern via the [tidelift platform](https://tidelift.com/security).
