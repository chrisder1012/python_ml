# Example config used by load_config_app.py

c = get_config()  # noqa
c.MyClass.name = 'coolname'
c.MyClass.ranking = 100
