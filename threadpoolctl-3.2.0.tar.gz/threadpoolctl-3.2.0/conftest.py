collect_ignore = ["tests/_openmp_test_helper"]
