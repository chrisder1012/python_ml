This directory contains a file with the license of each third party software component used by GSA-Grasshopper.
