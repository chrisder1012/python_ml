﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using GH_IO.Serialization;
using Grasshopper;
using Grasshopper.Kernel;
using Grasshopper.Kernel.Data;
using Grasshopper.Kernel.Types;
using GsaGH.Helpers.GH;
using GsaGH.Helpers.Graphics;
using GsaGH.Helpers.Import;
using GsaGH.Parameters;
using GsaGH.Properties;
using Newtonsoft.Json;
using OasysGH;
using OasysGH.Components;
using OasysGH.Parameters;
using OasysGH.UI;
using OasysGH.Units;
using OasysGH.Units.Helpers;
using OasysUnits;
using OasysUnits.Serialization.JsonNet;
using Rhino.Display;
using Rhino.Geometry;
using LengthUnit = OasysUnits.Units.LengthUnit;

namespace GsaGH.Components {
  /// <summary>
  ///   Component to retrieve geometric objects from a GSA model
  /// </summary>
  public class GetGeometry : GH_OasysTaskCapableComponent<GetGeometry.SolveResults>,
    IGH_VariableParameterComponent {
    public class SolveResults {
      internal ConcurrentBag<GsaNodeGoo> DisplaySupports { get; set; }
      internal ConcurrentBag<GsaElement1dGoo> Elem1ds { get; set; }
      internal ConcurrentBag<GsaElement2dGoo> Elem2ds { get; set; }
      internal ConcurrentBag<GsaElement3dGoo> Elem3ds { get; set; }
      internal ConcurrentBag<GsaMember1dGoo> Mem1ds { get; set; }
      internal ConcurrentBag<GsaMember2dGoo> Mem2ds { get; set; }
      internal ConcurrentBag<GsaMember3dGoo> Mem3ds { get; set; }
      internal ConcurrentBag<GsaNodeGoo> Nodes { get; set; }
    }

    private enum FoldMode {
      Graft,
      List,
    }

    public override BoundingBox ClippingBox => _boundingBox;
    public override Guid ComponentGuid => new Guid("6c4cb686-a6d1-4a79-b01b-fadc5d6da520");
    public override GH_Exposure Exposure => GH_Exposure.secondary;
    public override OasysPluginInfo PluginInfo => GsaGH.PluginInfo.Instance;
    public List<List<string>> _dropDownItems;
    public bool _isInitialised;
    public List<string> _selectedItems;
    public List<string> _spacerDescriptions;
    public bool AlwaysExpireDownStream;
    public Dictionary<int, List<string>> ExistingOutputsSerialized
      = new Dictionary<int, List<string>>();
    protected override Bitmap Icon => Resources.GetGeometry;
    private static readonly OasysUnitsIQuantityJsonConverter converter
      = new OasysUnitsIQuantityJsonConverter();
    private BoundingBox _boundingBox;
    private Mesh _cachedDisplayMeshWithoutParent;
    private Mesh _cachedDisplayMeshWithParent;
    private Mesh _cachedDisplayNgonMeshWithoutParent;
    private Mesh _cachedDisplayNgonMeshWithParent;
    private ConcurrentBag<GsaElement2dGoo> _element2ds;
    private ConcurrentBag<GsaElement3dGoo> _element3ds;
    private LengthUnit _lengthUnit = DefaultUnits.LengthUnitGeometry;
    private FoldMode _mode = FoldMode.List;
    private Dictionary<int, bool> _outputIsExpired = new Dictionary<int, bool>();
    private Dictionary<int, List<bool>> _outputsAreExpired = new Dictionary<int, List<bool>>();
    private ConcurrentBag<GsaNodeGoo> _supportNodes;

    public GetGeometry() : base("Get Model Geometry", "GetGeo",
      "Get nodes, elements and members from GSA model", CategoryName.Name(),
      SubCategoryName.Cat0()) { }

    bool IGH_VariableParameterComponent.CanInsertParameter(GH_ParameterSide side, int index) {
      return false;
    }

    bool IGH_VariableParameterComponent.CanRemoveParameter(GH_ParameterSide side, int index) {
      return false;
    }

    public override void CreateAttributes() {
      if (!_isInitialised) {
        InitialiseDropdowns();
      }

      m_attributes = new DropDownComponentAttributes(this, SetSelected, _dropDownItems,
        _selectedItems, _spacerDescriptions);
    }

    IGH_Param IGH_VariableParameterComponent.CreateParameter(GH_ParameterSide side, int index) {
      return null;
    }

    bool IGH_VariableParameterComponent.DestroyParameter(GH_ParameterSide side, int index) {
      return false;
    }

    public override void DrawViewportMeshes(IGH_PreviewArgs args) {
      base.DrawViewportMeshes(args);
      if (Attributes.Selected) {
        if (_cachedDisplayMeshWithoutParent != null) {
          args.Display.DrawMeshShaded(_cachedDisplayMeshWithoutParent, Colours.Element2dFace);
        }

        if (_cachedDisplayNgonMeshWithoutParent != null) {
          args.Display.DrawMeshShaded(_cachedDisplayNgonMeshWithoutParent, Colours.Element2dFace);
        }
      } else {
        if (_cachedDisplayMeshWithoutParent != null) {
          args.Display.DrawMeshShaded(_cachedDisplayMeshWithoutParent,
            Colours.Element2dFaceSelected);
        }

        if (_cachedDisplayNgonMeshWithoutParent != null) {
          args.Display.DrawMeshShaded(_cachedDisplayNgonMeshWithoutParent,
            Colours.Element2dFaceSelected);
        }
      }
    }

    public override void DrawViewportWires(IGH_PreviewArgs args) {
      base.DrawViewportWires(args);

      if (_cachedDisplayMeshWithParent != null) {
        args.Display.DrawMeshWires(_cachedDisplayMeshWithParent, Color.FromArgb(255, 229, 229, 229),
          1);
      }

      if (_cachedDisplayNgonMeshWithParent != null) {
        args.Display.DrawMeshWires(_cachedDisplayNgonMeshWithParent,
          Color.FromArgb(255, 229, 229, 229), 1);
      }

      if (_cachedDisplayMeshWithoutParent != null) {
        if (Attributes.Selected) {
          args.Display.DrawMeshWires(_cachedDisplayMeshWithoutParent, Colours.Element2dEdgeSelected,
            2);
        } else {
          args.Display.DrawMeshWires(_cachedDisplayMeshWithoutParent, Colours.Element2dEdge, 1);
        }
      }

      if (_cachedDisplayNgonMeshWithoutParent != null) {
        if (Attributes.Selected) {
          args.Display.DrawMeshWires(_cachedDisplayNgonMeshWithoutParent,
            Colours.Element2dEdgeSelected, 2);
        } else {
          args.Display.DrawMeshWires(_cachedDisplayNgonMeshWithoutParent, Colours.Element2dEdge, 1);
        }
      }

      if (_supportNodes == null) {
        return;
      }

      foreach (GsaNodeGoo node in _supportNodes) {
        if (node.Value.Point.IsValid) {
          if (!Attributes.Selected) {
            if (node.Value.Colour != Color.FromArgb(0, 0, 0)) {
              args.Display.DrawPoint(node.Value.Point, PointStyle.RoundSimple, 3,
                node.Value.Colour);
            } else {
              Color col = Colours.Node;
              args.Display.DrawPoint(node.Value.Point, PointStyle.RoundSimple, 3, col);
            }

            if (node.Value._previewSupportSymbol != null) {
              args.Display.DrawBrepShaded(node.Value._previewSupportSymbol, Colours.SupportSymbol);
            }

            if (node.Value._previewText != null) {
              args.Display.Draw3dText(node.Value._previewText, Colours.Support);
            }
          } else {
            args.Display.DrawPoint(node.Value.Point, PointStyle.RoundControlPoint, 3,
              Colours.NodeSelected);
            if (node.Value._previewSupportSymbol != null) {
              args.Display.DrawBrepShaded(node.Value._previewSupportSymbol,
                Colours.SupportSymbolSelected);
            }

            if (node.Value._previewText != null) {
              args.Display.Draw3dText(node.Value._previewText, Colours.NodeSelected);
            }
          }

          if (!node.Value.IsGlobalAxis()) {
            args.Display.DrawLine(node.Value._previewXaxis, Color.FromArgb(255, 244, 96, 96), 1);
            args.Display.DrawLine(node.Value._previewYaxis, Color.FromArgb(255, 96, 244, 96), 1);
            args.Display.DrawLine(node.Value._previewZaxis, Color.FromArgb(255, 96, 96, 234), 1);
          }
        }
      }
    }

    public void InitialiseDropdowns() {
      _spacerDescriptions = new List<string>(new[] {
        "Unit",
      });

      _dropDownItems = new List<List<string>>();
      _selectedItems = new List<string>();

      _dropDownItems.Add(UnitsHelper.GetFilteredAbbreviations(EngineeringUnits.Length));
      _selectedItems.Add(Length.GetAbbreviation(_lengthUnit));

      _isInitialised = true;
    }

    public void OutputChanged<T>(T data, int outputIndex, int index) where T : IGH_Goo {
      if (!ExistingOutputsSerialized.ContainsKey(outputIndex)) {
        ExistingOutputsSerialized.Add(outputIndex, new List<string>());
        _outputsAreExpired.Add(outputIndex, new List<bool>());
      }

      string text;
      if (data.GetType() == typeof(GH_UnitNumber)) {
        text = JsonConvert.SerializeObject(((GH_UnitNumber)(object)data).Value, converter);
      } else {
        object value = data.ScriptVariable();
        try {
          text = JsonConvert.SerializeObject(value);
        } catch (Exception) {
          text = data.GetHashCode().ToString();
        }
      }

      if (ExistingOutputsSerialized[outputIndex].Count == index) {
        ExistingOutputsSerialized[outputIndex].Add(text);
        _outputsAreExpired[outputIndex].Add(true);
      } else if (ExistingOutputsSerialized[outputIndex][index] != text) {
        ExistingOutputsSerialized[outputIndex][index] = text;
        _outputsAreExpired[outputIndex][index] = true;
      } else {
        _outputsAreExpired[outputIndex][index] = false;
      }
    }

    public override bool Read(GH_IReader reader) {
      _mode = (FoldMode)reader.GetInt32("Mode");
      ReadDropDownComponents(ref reader, ref _dropDownItems, ref _selectedItems,
        ref _spacerDescriptions);
      _isInitialised = true;
      UpdateUiFrom_selectedItems();
      return base.Read(reader);
    }

    public void SetSelected(int i, int j) {
      _selectedItems[i] = _dropDownItems[i][j];
      _lengthUnit = (LengthUnit)UnitsHelper.Parse(typeof(LengthUnit), _selectedItems[i]);
      UpdateUi();
    }

    public virtual void UpdateUi() {
      ((IGH_VariableParameterComponent)this).VariableParameterMaintenance();
      ExpireSolution(true);
      Params.OnParametersChanged();
      OnDisplayExpired(true);
    }

    public void UpdateUiFrom_selectedItems() {
      _lengthUnit = (LengthUnit)UnitsHelper.Parse(typeof(LengthUnit), _selectedItems[0]);
      CreateAttributes();
      UpdateUi();
    }

    void IGH_VariableParameterComponent.VariableParameterMaintenance() {
      string unitAbbreviation = Length.GetAbbreviation(_lengthUnit);

      int i = 0;
      Params.Output[i++].Name = "Nodes [" + unitAbbreviation + "]";
      Params.Output[i++].Name = "1D Elements [" + unitAbbreviation + "]";
      Params.Output[i++].Name = "2D Elements [" + unitAbbreviation + "]";
      Params.Output[i++].Name = "3D Elements [" + unitAbbreviation + "]";
      Params.Output[i++].Name = "1D Members [" + unitAbbreviation + "]";
      Params.Output[i++].Name = "2D Members [" + unitAbbreviation + "]";
      Params.Output[i].Name = "3D Members [" + unitAbbreviation + "]";

      i = 1;
      for (int j = 1; j < 7; j++) {
        Params.Output[i].Access
          = _mode == FoldMode.List ? GH_ParamAccess.list : GH_ParamAccess.tree;
      }
    }

    public override bool Write(GH_IWriter writer) {
      writer.SetInt32("Mode", (int)_mode);
      WriteDropDownComponents(ref writer, _dropDownItems, _selectedItems, _spacerDescriptions);

      return base.Write(writer);
    }

    internal static void ReadDropDownComponents(
      ref GH_IReader reader, ref List<List<string>> dropDownItems, ref List<string> selectedItems,
      ref List<string> spacerDescriptions) {
      if (reader.GetBoolean("dropdown")) {
        int dropdownCount = reader.GetInt32("dropdownCount");
        dropDownItems = new List<List<string>>();
        for (int i = 0; i < dropdownCount; i++) {
          int dropdowncontentsCount = reader.GetInt32("dropdowncontentsCount" + i);
          var tempcontent = new List<string>();
          for (int j = 0; j < dropdowncontentsCount; j++) {
            tempcontent.Add(reader.GetString("dropdowncontents" + i + j));
          }

          dropDownItems.Add(tempcontent);
        }
      } else {
        throw new Exception("Component doesnt have 'dropdown' content stored");
      }

      if (reader.GetBoolean("spacer")) {
        int dropdownspacerCount = reader.GetInt32("spacerCount");
        spacerDescriptions = new List<string>();
        for (int i = 0; i < dropdownspacerCount; i++) {
          spacerDescriptions.Add(reader.GetString("spacercontents" + i));
        }
      }

      if (!reader.GetBoolean("select")) {
        return;
      }

      int selectionsCount = reader.GetInt32("selectionCount");
      selectedItems = new List<string>();
      for (int i = 0; i < selectionsCount; i++) {
        selectedItems.Add(reader.GetString("selectioncontents" + i));
      }
    }

    internal static GH_IWriter WriteDropDownComponents(
      ref GH_IWriter writer, List<List<string>> dropDownItems, List<string> selectedItems,
      List<string> spacerDescriptions) {
      bool dropdown = false;
      if (dropDownItems != null) {
        writer.SetInt32("dropdownCount", dropDownItems.Count);
        for (int i = 0; i < dropDownItems.Count; i++) {
          writer.SetInt32("dropdowncontentsCount" + i, dropDownItems[i].Count);
          for (int j = 0; j < dropDownItems[i].Count; j++) {
            writer.SetString("dropdowncontents" + i + j, dropDownItems[i][j]);
          }
        }

        dropdown = true;
      }

      writer.SetBoolean("dropdown", dropdown);

      bool spacer = false;
      if (spacerDescriptions != null) {
        writer.SetInt32("spacerCount", spacerDescriptions.Count);
        for (int i = 0; i < spacerDescriptions.Count; i++) {
          writer.SetString("spacercontents" + i, spacerDescriptions[i]);
        }

        spacer = true;
      }

      writer.SetBoolean("spacer", spacer);

      bool select = false;
      if (selectedItems != null) {
        writer.SetInt32("selectionCount", selectedItems.Count);
        for (int i = 0; i < selectedItems.Count; i++) {
          writer.SetString("selectioncontents" + i, selectedItems[i]);
        }

        select = true;
      }

      writer.SetBoolean("select", select);

      return writer;
    }

    protected override void AppendAdditionalComponentMenuItems(ToolStripDropDown menu) {
      if (!(menu is ContextMenuStrip)) {
        return; // this method is also called when clicking EWR balloon
      }

      Menu_AppendItem(menu, "Graft by Property", GraftModeClicked, true, _mode == FoldMode.Graft);
      Menu_AppendItem(menu, "List", ListModeClicked, true, _mode == FoldMode.List);
    }

    protected override void ExpireDownStreamObjects() {
      if (AlwaysExpireDownStream) {
        base.ExpireDownStreamObjects();
        return;
      }

      SetExpireDownStream();
      if (_outputIsExpired.Count > 0) {
        for (int i = 0; i < Params.Output.Count; i++) {
          if (_outputIsExpired[i]) {
            Params.Output[i].ExpireSolution(false);
          }
        }
      } else {
        base.ExpireDownStreamObjects();
      }
    }

    protected override void RegisterInputParams(GH_InputParamManager pManager) {
      pManager.AddParameter(new GsaModelParameter(), "GSA Model", "GSA",
        "GSA model containing some geometry", GH_ParamAccess.item);
      pManager.AddGenericParameter("Node filter list", "No",
        "Filter import by list. (by default 'all')" + Environment.NewLine + "Node list should take the form:"
        + Environment.NewLine + " 1 11 to 72 step 2 not (XY3 31 to 45)" + Environment.NewLine
        + "Refer to GSA help file for definition of lists and full vocabulary.",
        GH_ParamAccess.item);
      pManager.AddGenericParameter("Element filter list", "El",
        "Filter import by list (by default 'all')." + Environment.NewLine + "Element list should take the form:"
        + Environment.NewLine
        + " 1 11 to 20 step 2 P1 not (G1 to G6 step 3) P11 not (PA PB1 PS2 PM3 PA4 M1)"
        + Environment.NewLine
        + "Refer to GSA help file for definition of lists and full vocabulary.",
        GH_ParamAccess.item);
      pManager.AddGenericParameter("Member filter list", "Me",
        "Filter import by list (by default 'all')." + Environment.NewLine + "Member list should take the form:"
        + Environment.NewLine + " 1 11 to 20 step 2 P1 not (G1 to G6 step 3) P11 not (Z4 XY55)"
        + Environment.NewLine
        + "Refer to GSA help file for definition of lists and full vocabulary.",
        GH_ParamAccess.item);
      pManager[1].Optional = true;
      pManager[2].Optional = true;
      pManager[3].Optional = true;
    }

    protected override void RegisterOutputParams(GH_OutputParamManager pManager) {
      string unitAbbreviation = Length.GetAbbreviation(_lengthUnit);

      pManager.AddParameter(new GsaNodeParameter(), "Nodes [" + unitAbbreviation + "]", "No", "Nodes from GSA Model",
        GH_ParamAccess.list);
      pManager.HideParameter(0);
      pManager.AddParameter(new GsaElement1dParameter(), "1D Elements [" + unitAbbreviation + "]", "E1D",
        "1D Elements (Analysis Layer) from GSA Model imported to selected unit",
        GH_ParamAccess.list);
      pManager.AddParameter(new GsaElement2dParameter(), "2D Elements [" + unitAbbreviation + "]", "E2D",
        "2D Elements (Analysis Layer) from GSA Model imported to selected unit",
        GH_ParamAccess.list);
      pManager.AddParameter(new GsaElement3dParameter(), "3D Elements [" + unitAbbreviation + "]", "E3D",
        "3D Elements (Analysis Layer) from GSA Model imported to selected unit",
        GH_ParamAccess.list);
      pManager.HideParameter(2);
      pManager.AddParameter(new GsaMember1dParameter(), "1D Members [" + unitAbbreviation + "]", "M1D",
        "1D Members (Design Layer) from GSA Model imported to selected unit", GH_ParamAccess.tree);
      pManager.AddParameter(new GsaMember2dParameter(), "2D Members [" + unitAbbreviation + "]", "M2D",
        "2D Members (Design Layer) from GSA Model imported to selected unit", GH_ParamAccess.tree);
      pManager.AddParameter(new GsaMember3dParameter(), "3D Members [" + unitAbbreviation + "]", "M3D",
        "3D Members (Design Layer) from GSA Model imported to selected unit", GH_ParamAccess.tree);
    }

    protected override void SolveInstance(IGH_DataAccess data) {
      var memberKeys = new List<int>();
      if (InPreSolve) {
        GsaModelGoo modelGoo = null;
        data.GetData(0, ref modelGoo);

        Task<SolveResults> tsk = null;

        var ghTyp = new GH_ObjectWrapper();
        string nodeList = "all";
        if (data.GetData(1, ref ghTyp)) {
          if (ghTyp.Value is GsaListGoo listGoo) {
            if (listGoo.Value.EntityType != Parameters.EntityType.Node) {
              this.AddRuntimeWarning(
              "List must be of type Node to apply to node filter");
            }
            nodeList = $"\"{listGoo.Value.Name}\"";
          } else {
            GH_Convert.ToString(ghTyp.Value, out nodeList, GH_Conversion.Both);
          }
        }
        string elemList = "all";
        if (data.GetData(2, ref ghTyp)) {
          if (ghTyp.Value is GsaListGoo listGoo) {
            if (listGoo.Value.EntityType != Parameters.EntityType.Element) {
              this.AddRuntimeWarning(
              "List must be of type Element to apply to element filter");
            }
            elemList = $"\"{listGoo.Value.Name}\"";
          } else {
            GH_Convert.ToString(ghTyp.Value, out elemList, GH_Conversion.Both);
          }
        }
        string memList = "all";
        if (data.GetData(3, ref ghTyp)) {
          if (ghTyp.Value is GsaListGoo listGoo) {
            if (listGoo.Value.EntityType != Parameters.EntityType.Member) {
              this.AddRuntimeWarning(
              "List must be of type Member to apply to member filter");
            }
            memList = $"\"{listGoo.Value.Name}\"";
          } else {
            GH_Convert.ToString(ghTyp.Value, out memList, GH_Conversion.Both);
          }
        }

        tsk = Task.Run(
          () => Compute(modelGoo.Value, nodeList, elemList, memList), CancelToken);


        TaskList.Add(tsk);
        return;
      }

      if (!GetSolveResults(data, out SolveResults results)) {
        GsaModelGoo modelGoo = null;
        data.GetData(0, ref modelGoo);

        string nodeList = "all";
        data.GetData(1, ref nodeList);
        string elemList = "all";
        data.GetData(2, ref elemList);
        string memList = "all";
        data.GetData(3, ref memList);

        results = Compute(modelGoo.Value, nodeList, elemList, memList);
      }

      if (results is null) {
        return;
      }

      if (!(results.Nodes is null)) {
        data.SetDataList(0, results.Nodes.OrderBy(item => item.Value.Id));
        _supportNodes = results.DisplaySupports;
        _boundingBox = new BoundingBox(results.Nodes.Select(n => n.Value.Point).ToArray());
      }

      if (!(results.Elem1ds is null)) {
        var invalid1dElem = results.Elem1ds.Where(x => !x.IsValid).Select(x => x.Value.Id).ToList();
        if (invalid1dElem.Count > 0) {
          this.AddRuntimeWarning("Invalid Element1D definition for Element IDs:");
          this.AddRuntimeWarning(string.Join(" ", invalid1dElem.OrderBy(x => x)));
        }

        if (_mode == FoldMode.List) {
          data.SetDataList(1, results.Elem1ds.OrderBy(item => item.Value.Id));
        } else {
          var tree = new DataTree<GsaElement1dGoo>();
          foreach (GsaElement1dGoo element in results.Elem1ds) {
            tree.Add(element, new GH_Path(element.Value.Section.Id));
          }

          data.SetDataTree(1, tree);
        }
      }

      if (!(results.Elem2ds is null)) {
        if (_mode == FoldMode.List) {
          data.SetDataList(2, results.Elem2ds.OrderBy(item => item.Value.Ids.First()));
        } else {
          var tree = new DataTree<GsaElement2dGoo>();
          foreach (GsaElement2dGoo element in results.Elem2ds) {
            tree.Add(element, new GH_Path(element.Value.Prop2ds.First().Id));
          }

          data.SetDataTree(2, tree);
        }

        _element2ds = results.Elem2ds;

        var element2dsShaded = new ConcurrentBag<GsaElement2dGoo>();
        var element2dsNotShaded = new ConcurrentBag<GsaElement2dGoo>();
        Parallel.ForEach(_element2ds, elem => {
          try {
            int parent = elem.Value.ApiElements[0].ParentMember.Member;
            if (parent > 0 && memberKeys.Contains(parent)) {
              element2dsShaded.Add(elem);
            } else {
              element2dsNotShaded.Add(elem);
            }
          } catch (Exception) {
            element2dsNotShaded.Add(elem);
          }
        });
        _cachedDisplayMeshWithParent = new Mesh();
        _cachedDisplayMeshWithParent.Append(element2dsShaded.Select(e => e.Value.Mesh));
        _cachedDisplayMeshWithoutParent = new Mesh();
        _cachedDisplayMeshWithoutParent.Append(element2dsNotShaded.Select(e => e.Value.Mesh));
      }

      if (!(results.Elem3ds is null)) {
        if (_mode == FoldMode.List) {
          data.SetDataList(3, results.Elem3ds.OrderBy(item => item.Value.Ids.First()));
        } else {
          var tree = new DataTree<GsaElement3dGoo>();
          foreach (GsaElement3dGoo element in results.Elem3ds) {
            tree.Add(element, new GH_Path(element.Value.PropertyIDs.First()));
          }

          data.SetDataTree(3, tree);
        }

        _element3ds = results.Elem3ds;
        var element3dsShaded = new ConcurrentBag<GsaElement3dGoo>();
        var element3dsNotShaded = new ConcurrentBag<GsaElement3dGoo>();
        Parallel.ForEach(_element3ds, elem => {
          try {
            int parent = elem.Value.ApiElements[0].ParentMember.Member;
            if (parent > 0 && memberKeys.Contains(parent)) {
              element3dsShaded.Add(elem);
            } else {
              element3dsNotShaded.Add(elem);
            }
          } catch (Exception) {
            element3dsNotShaded.Add(elem);
          }
        });
        _cachedDisplayNgonMeshWithParent = new Mesh();
        _cachedDisplayNgonMeshWithParent.Append(element3dsShaded.Select(e => e.Value.DisplayMesh));
        _cachedDisplayNgonMeshWithoutParent = new Mesh();
        _cachedDisplayNgonMeshWithoutParent.Append(
          element3dsNotShaded.Select(e => e.Value.DisplayMesh));
      }

      if (!(results.Mem1ds is null)) {
        var invalid1dMem = results.Mem1ds.Where(x => !x.IsValid).Select(x => x.Value.Id).ToList();
        if (invalid1dMem.Count > 0) {
          this.AddRuntimeWarning("Invalid Member1D definition for Member IDs:");
          this.AddRuntimeWarning(string.Join(" ", invalid1dMem.OrderBy(x => x)));
        }

        if (_mode == FoldMode.List) {
          data.SetDataList(4, results.Mem1ds.OrderBy(item => item.Value.Id));
        } else {
          var tree = new DataTree<GsaMember1dGoo>();
          foreach (GsaMember1dGoo element in results.Mem1ds) {
            tree.Add(element, new GH_Path(element.Value.Section.Id));
          }

          data.SetDataTree(4, tree);
        }
      }

      if (!(results.Mem2ds is null)) {
        var invalid2dMem = results.Mem2ds.Where(x => !x.IsValid).Select(x => x.Value.Id).ToList();
        if (invalid2dMem.Count > 0) {
          this.AddRuntimeWarning("Invalid Member2D definition for Member IDs:");
          this.AddRuntimeWarning(string.Join(" ", invalid2dMem.OrderBy(x => x)));
        }

        if (_mode == FoldMode.List) {
          data.SetDataList(5, results.Mem2ds.OrderBy(item => item.Value.Id));
        } else {
          var tree = new DataTree<GsaMember2dGoo>();
          foreach (GsaMember2dGoo element in results.Mem2ds) {
            tree.Add(element, new GH_Path(element.Value.Prop2d.Id));
          }

          data.SetDataTree(5, tree);
        }
      }

      if (results.Mem3ds is null) {
        return;
      }
      {
        var invalid3dMem = results.Mem3ds.Where(x => !x.IsValid).Select(x => x.Value.Id).ToList();
        if (invalid3dMem.Count > 0) {
          this.AddRuntimeWarning("Invalid Member3D definition for Member IDs:");
          this.AddRuntimeWarning(string.Join(" ", invalid3dMem.OrderBy(x => x)));
        }

        if (_mode == FoldMode.List) {
          data.SetDataList(6, results.Mem3ds.OrderBy(item => item.Value.Id));
        } else {
          var tree = new DataTree<GsaMember3dGoo>();
          foreach (GsaMember3dGoo element in results.Mem3ds) {
            tree.Add(element, new GH_Path(element.Value.Prop3d.Id));
          }

          data.SetDataTree(6, tree);
        }
      }
    }

    private SolveResults Compute(GsaModel model, string nodeList, string elemList, string memList) { 
      var results = new SolveResults();
      var steps = new List<int> {
        0, 1, 2,
      };

      if (model.ModelUnit != _lengthUnit) {
        model.ModelUnit = _lengthUnit;
      }

      try {
        Parallel.ForEach(steps, i => {
          switch (i) {
            case 0:
              results.Nodes = Nodes.GetNodes(
                nodeList.ToLower() == "all" ? model.ApiNodes : model.Model.Nodes(nodeList), 
                model.ModelUnit, 
                model.ApiAxis);
              results.DisplaySupports
                = new ConcurrentBag<GsaNodeGoo>(results.Nodes.Where(n => n.Value.IsSupport));
              break;

            case 1:
              var elements = new Elements(model, elemList);
              results.Elem1ds = elements.Element1ds;
              results.Elem2ds = elements.Element2ds;
              results.Elem3ds = elements.Element3ds;
              break;

            case 2:
              var members = new Members(model, memList, this);
              results.Mem1ds = members.Member1ds; 
              results.Mem2ds = members.Member2ds; 
              results.Mem3ds = members.Member3ds;
              break;
          }
        });
      } catch (Exception e) {
        this.AddRuntimeWarning(e.InnerException?.Message);
      }

      return results;
    }

    private void GraftModeClicked(object sender, EventArgs e) {
      if (_mode == FoldMode.Graft) {
        return;
      }

      RecordUndoEvent("Graft by Property");
      _mode = FoldMode.Graft;

      (this as IGH_VariableParameterComponent).VariableParameterMaintenance();
      Params.OnParametersChanged();
      Message = "Graft by Property";
      ExpireSolution(true);
    }

    private void ListModeClicked(object sender, EventArgs e) {
      if (_mode == FoldMode.List) {
        return;
      }

      RecordUndoEvent("List");
      _mode = FoldMode.List;

      (this as IGH_VariableParameterComponent).VariableParameterMaintenance();
      Params.OnParametersChanged();
      Message = "Import as List";
      ExpireSolution(true);
    }

    private void SetExpireDownStream() {
      if (_outputsAreExpired == null || _outputsAreExpired.Count <= 0) {
        return;
      }

      _outputIsExpired = new Dictionary<int, bool>();
      for (int i = 0; i < Params.Output.Count; i++) {
        if (_outputsAreExpired.ContainsKey(i)) {
          _outputIsExpired.Add(i, _outputsAreExpired[i].Any(c => c));
        } else {
          _outputIsExpired.Add(i, true);
        }
      }
    }
  }
}
