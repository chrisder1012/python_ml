﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GsaGH.Parameters.Enums {
  internal class GridLoad {
    internal enum ExpansionType {
      UseGpsSettings = 0,
      To1D = 1,
      To2D = 2,
    }
  }
}
