﻿namespace GsaGH.Parameters.Enums {
  public enum Prop2dType {
    Undefined = 0,
    PlaneStress = 1,
    Fabric = 4,
    FlatPlate = 5,
    Shell = 6,
    CurvedShell = 7,
    LoadPanel = 10,
  }
}
