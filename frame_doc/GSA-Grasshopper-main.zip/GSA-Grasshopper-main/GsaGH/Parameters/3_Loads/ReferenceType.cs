﻿namespace GsaGH.Parameters {
  public enum ReferenceType {
    None,
    Property,
    Element,
    MemberChildElements,
    Member,
    List,
  }
}
