namespace Tunny.Storage
{
    public enum TrialState
    {
        RUNNING,
        WAITING,
        COMPLETE,
        PRUNED,
        FAIL
    }
}
