namespace Tunny.Settings
{
    public class Result
    {
        public string OutputNumberString { get; set; } = "0";
        public int SelectVisualizeType { get; set; } = 3;
        public int NumberOfClusters { get; set; } = 3;
    }
}
