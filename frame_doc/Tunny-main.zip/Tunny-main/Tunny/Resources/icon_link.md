# Link to the data used in the icon

- Tunny Icon
  - https://xn--icon-rainbow-5s53b.com/%E3%81%BE%E3%81%90%E3%82%8D%E3%81%AE%E7%84%A1%E6%96%99%E3%82%A2%E3%82%A4%E3%82%B3%E3%83%B3%E7%B4%A0%E6%9D%90-3/
- ParamFish Icon
  - https://icooon-mono.com/15801-%e3%83%9e%e3%82%b0%e3%83%ad%e3%82%a2%e3%82%a4%e3%82%b3%e3%83%b31/
- FishMarket Icon
  - https://icon-rainbow.com/%e3%81%be%e3%81%90%e3%82%8d%e3%81%ae%e7%84%a1%e6%96%99%e3%82%a2%e3%82%a4%e3%82%b3%e3%83%b3%e7%b4%a0%e6%9d%90-1/
- Attribute gear
  - https://icooon-mono.com/14476-%E6%AD%AF%E8%BB%8A%E3%82%A2%E3%82%A4%E3%82%B3%E3%83%B310/
- Deconstruct Fire
  - https://icooon-mono.com/13073-fire-icon/?lang=en
- Fish Egg
  - https://icooon-mono.com/15187-%e9%bb%84%e9%87%91%e3%81%ae%e5%8d%b5%e3%82%a2%e3%82%a4%e3%82%b3%e3%83%b3/
- Param_FishPrint
  - https://icooon-mono.com/11196-%e3%82%ab%e3%83%a1%e3%83%a9%e3%81%ae%e3%82%a2%e3%82%a4%e3%82%b3%e3%83%b3%e7%b4%a0%e6%9d%90-6/
- FishPrintByPath
  - https://icooon-mono.com/11375-%e3%82%b7%e3%83%b3%e3%83%97%e3%83%ab%e3%81%aa%e3%83%95%e3%82%a9%e3%83%ab%e3%83%80%e3%82%a2%e3%82%a4%e3%82%b3%e3%83%b3/
