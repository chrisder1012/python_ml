namespace Tunny.Util
{
    public enum PlotActionType
    {
        Save,
        Show,
    }
}
