namespace Tunny.Util
{
    public enum OutputMode
    {
        ParatoSolutions,
        AllTrials,
        ModelNumber,
        ReflectToSliders
    }
}
