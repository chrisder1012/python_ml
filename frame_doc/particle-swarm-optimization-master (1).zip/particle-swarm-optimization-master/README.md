# Particle Swarm Optimization

An implementation of PSO
