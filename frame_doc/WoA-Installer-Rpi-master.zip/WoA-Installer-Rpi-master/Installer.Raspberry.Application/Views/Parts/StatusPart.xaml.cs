﻿using System.Windows.Controls;

namespace Installer.Raspberry.Application.Views.Parts
{
    /// <summary>
    /// Interaction logic for StatusPart.xaml
    /// </summary>
    public partial class StatusPart : UserControl
    {
        public StatusPart()
        {
            InitializeComponent();
        }
    }
}
