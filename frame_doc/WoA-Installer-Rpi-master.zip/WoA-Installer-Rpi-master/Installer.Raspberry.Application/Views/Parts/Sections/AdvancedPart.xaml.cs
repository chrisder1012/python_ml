﻿using System.Windows.Controls;

namespace Installer.Raspberry.Application.Views.Parts.Sections
{
    /// <summary>
    /// Interaction logic for AdvancedPart.xaml
    /// </summary>
    public partial class AdvancedPart : UserControl
    {
        public AdvancedPart()
        {
            InitializeComponent();
        }
    }
}
