﻿using System.Windows.Controls;

namespace Installer.Raspberry.Application.Views.Parts.Sections
{
    /// <summary>
    /// Interaction logic for WimOptionsPart.xaml
    /// </summary>
    public partial class WimOptionsPart : UserControl
    {
        public WimOptionsPart()
        {
            InitializeComponent();
        }
    }
}
