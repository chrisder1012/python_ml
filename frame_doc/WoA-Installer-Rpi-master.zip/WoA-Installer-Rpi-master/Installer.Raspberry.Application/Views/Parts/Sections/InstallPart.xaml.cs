﻿namespace Installer.Raspberry.Application.Views.Parts.Sections
{
    /// <summary>
    /// Interaction logic for InstallPart.xaml
    /// </summary>
    public partial class InstallPart
    {
        public InstallPart()
        {
            InitializeComponent();
        }
    }
}
