﻿using System.Windows.Controls;

namespace Installer.Raspberry.Application.Views.Parts.Sections
{
    /// <summary>
    /// Interaction logic for DiskSelectionPart.xaml
    /// </summary>
    public partial class DiskSelectionPart : UserControl
    {
        public DiskSelectionPart()
        {
            InitializeComponent();
        }
    }
}
