﻿namespace Installer.Raspberry.Application.Views
{
    
    public partial class TextViewerWindow
    {
        public TextViewerWindow()
        {
            InitializeComponent();
        }
    }
}
