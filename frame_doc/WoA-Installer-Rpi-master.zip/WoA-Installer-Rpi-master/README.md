﻿# WoA Installer for Raspberry Pi 3

## IMPORTANT NOTICE
This project has been discontinued. 

❗ Please use [WOA Deployer for Raspberry Pi](https://github.com/WOA-Project/WOA-Deployer-Rpi) instead