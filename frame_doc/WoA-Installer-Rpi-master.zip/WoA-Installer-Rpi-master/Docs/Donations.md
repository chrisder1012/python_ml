﻿
# Support my work

If you find this useful, feel free to [buy me a coffee ☕](http://paypal.me/superjmn). Thanks in advance!!

## Donate to contributors of the RaspberryPi WOA project
Please, don't forget that the RaspberryPi WOA Project is supported by other individuals and companies (see the [credits and acknowledgements section](#credits-and-acknowledgements)).
 - Donate to MCCI. Why? [Read this 🗒](mcci_donate.md) 