# WoA Installer for Lumia 950/XL

## IMPORTANT NEWS!

❗ This application has been replaced by **WOA Deployer**, the new iteration. 

Go to [WOA Deployer's Site](https://github.com/WOA-project/WOA-Deployer)
