Please use the "Preview" tab above to view this message if you are seeing this in the new issue text box.

Please note that this is a **WoA Installer** issue tracker, use this issue tracker only for the WoA Installer related bugs and enhancements.

Please use the [LumiaWoA](https://t.me/joinchat/Ey6mehEPg0Fe4utQNZ9yjA) or [RaspberryPiWOA](https://t.me/raspberrypiwoa) Telegram groups for anything else, such as:

 - Reporting bugs of other tools, drivers, etc.
 - Asking for help
 - Asking about project progress.

# Please remove the text above before opening an issue.
