   PARTICLE SWARM OPTIMIZATION vs WHALE OPTIMIZATION ALGORITHM  
    
  A comparision between PSO and WOA when run on different benchmark functions
  Ocatve/Matlab
  
-------------DIRECTIONS--------------
1> Run main.m 
2> To change the function for WOA change Function_name to anything between F1 to F22
2> To change the function for PSO go to spherefun.m and put the function manually

Pull request and Forks are welcome... 
:P 
