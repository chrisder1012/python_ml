# Assets

This folder's purpose is to store files that are linked to within the repo itself.
