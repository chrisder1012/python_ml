# Grasshopper Optimization Algorithm
simple grasshopper optimization algorithm (GOA) 
