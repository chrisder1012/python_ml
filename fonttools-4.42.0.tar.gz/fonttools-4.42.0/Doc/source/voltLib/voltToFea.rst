#################################################
voltToFea: Convert MS VOLT to AFDKO feature files
#################################################

.. automodule:: fontTools.voltLib.voltToFea
   :inherited-members:
   :members:
   :undoc-members:
