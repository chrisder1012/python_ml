#######
unicode
#######

.. automodule:: fontTools.unicode
   :inherited-members:
   :members:
   :undoc-members:
