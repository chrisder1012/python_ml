
#######
glifLib
#######

.. automodule:: fontTools.ufoLib.glifLib
   :inherited-members:
   :members:
   :undoc-members:
