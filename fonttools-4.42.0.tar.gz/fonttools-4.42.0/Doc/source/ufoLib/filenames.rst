
#########
filenames
#########

.. automodule:: fontTools.ufoLib.filenames
   :inherited-members:
   :members:
   :undoc-members:
