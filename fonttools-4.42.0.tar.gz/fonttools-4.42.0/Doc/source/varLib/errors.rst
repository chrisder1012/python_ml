######
errors
######

.. automodule:: fontTools.varLib.errors
   :inherited-members:
   :members:
   :undoc-members:
