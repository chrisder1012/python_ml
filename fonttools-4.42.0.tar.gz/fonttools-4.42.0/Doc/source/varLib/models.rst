######
models
######

.. automodule:: fontTools.varLib.models
   :inherited-members:
   :members:
   :undoc-members:
