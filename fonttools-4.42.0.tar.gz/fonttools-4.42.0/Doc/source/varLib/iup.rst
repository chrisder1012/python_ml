###
iup
###

.. automodule:: fontTools.varLib.iup
   :inherited-members:
   :members:
   :undoc-members:
