##########
momentsPen
##########

.. automodule:: fontTools.pens.momentsPen
   :inherited-members:
   :members:
   :undoc-members:
