##########
ttGlyphPen
##########

.. automodule:: fontTools.pens.ttGlyphPen
   :inherited-members:
   :members:
   :undoc-members:
