#########
filterPen
#########

.. automodule:: fontTools.pens.filterPen
   :inherited-members:
   :members:
   :undoc-members:
