#########
boundsPen
#########

.. automodule:: fontTools.pens.boundsPen
   :inherited-members:
   :members:
   :undoc-members:
