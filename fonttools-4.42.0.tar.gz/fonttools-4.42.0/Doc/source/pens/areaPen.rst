#######
areaPen
#######

.. automodule:: fontTools.pens.areaPen
   :inherited-members:
   :members:
   :undoc-members:
