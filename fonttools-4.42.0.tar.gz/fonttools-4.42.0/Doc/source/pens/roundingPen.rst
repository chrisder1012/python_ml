###########
roundingPen
###########

.. automodule:: fontTools.pens.roundingPen
   :inherited-members:
   :members:
   :undoc-members:
