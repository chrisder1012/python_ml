#########
xmlWriter
#########

.. automodule:: fontTools.misc.xmlWriter
   :inherited-members:
   :members:
   :undoc-members:
