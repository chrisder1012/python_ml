#######
symfont
#######

.. automodule:: fontTools.misc.symfont
   :inherited-members:
   :members:
   :undoc-members:
