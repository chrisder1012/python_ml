###########
psOperators
###########

.. automodule:: fontTools.misc.psOperators
   :inherited-members:
   :members:
   :undoc-members:
