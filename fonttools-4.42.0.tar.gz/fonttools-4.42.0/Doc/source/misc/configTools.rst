###########
configTools
###########

.. automodule:: fontTools.misc.configTools
   :inherited-members:
   :members:
   :undoc-members:
