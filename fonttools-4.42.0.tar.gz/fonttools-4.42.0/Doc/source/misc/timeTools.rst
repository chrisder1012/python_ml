#########
timeTools
#########

.. automodule:: fontTools.misc.timeTools
   :inherited-members:
   :members:
   :undoc-members:
