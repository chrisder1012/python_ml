#########
xmlReader
#########

.. automodule:: fontTools.misc.xmlReader
   :inherited-members:
   :members:
   :undoc-members:
