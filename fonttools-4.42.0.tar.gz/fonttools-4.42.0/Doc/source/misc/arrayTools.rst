#############################################
arrayTools: Various array and rectangle tools
#############################################

.. automodule:: fontTools.misc.arrayTools
   :member-order: bysource
   :inherited-members:
   :members:
   :undoc-members:
