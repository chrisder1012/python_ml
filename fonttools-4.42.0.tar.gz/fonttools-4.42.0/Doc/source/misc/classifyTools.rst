#############
classifyTools
#############

.. automodule:: fontTools.misc.classifyTools
   :inherited-members:
   :members:
   :undoc-members:
