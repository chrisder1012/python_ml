###############################################
intTools: Tools for working with integer values
###############################################

.. automodule:: fontTools.misc.intTools
   :members:
