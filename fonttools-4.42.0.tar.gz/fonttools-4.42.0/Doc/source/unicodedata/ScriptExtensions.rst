################
ScriptExtensions
################

.. automodule:: fontTools.unicodedata.ScriptExtensions
   :inherited-members:
   :members:
   :undoc-members:

.. data:: fontTools.unicodedata.ScriptExtensions.RANGES

.. data:: fontTools.unicodedata.ScriptExtensions.VALUES
