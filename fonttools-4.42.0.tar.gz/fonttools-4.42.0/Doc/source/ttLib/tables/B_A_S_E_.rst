``BASE``: Baseline Table
------------------------

.. automodule:: fontTools.ttLib.tables.B_A_S_E_
   :inherited-members:
   :members:
   :undoc-members:

