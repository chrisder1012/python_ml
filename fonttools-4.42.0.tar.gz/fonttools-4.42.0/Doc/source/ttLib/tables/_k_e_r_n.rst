``kern``: Kerning
-----------------

.. automodule:: fontTools.ttLib.tables._k_e_r_n
   :inherited-members:
   :members:
   :undoc-members:

