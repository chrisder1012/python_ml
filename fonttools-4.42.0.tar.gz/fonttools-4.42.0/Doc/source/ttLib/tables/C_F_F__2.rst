``CFF2``: Compact Font Format (CFF) Version 2
---------------------------------------------

.. automodule:: fontTools.ttLib.tables.C_F_F__2
   :inherited-members:
   :members:
   :undoc-members:

