``VORG``: Vertical Origin Table
-------------------------------

.. automodule:: fontTools.ttLib.tables.V_O_R_G_
   :inherited-members:
   :members:
   :undoc-members:

