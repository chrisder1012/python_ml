``lcar``: Ligature Caret Table
------------------------------

.. automodule:: fontTools.ttLib.tables._l_c_a_r
   :inherited-members:
   :members:
   :undoc-members:

