``HVAR``:Horizontal Metrics Variations Table
--------------------------------------------

.. automodule:: fontTools.ttLib.tables.H_V_A_R_
   :inherited-members:
   :members:
   :undoc-members:
