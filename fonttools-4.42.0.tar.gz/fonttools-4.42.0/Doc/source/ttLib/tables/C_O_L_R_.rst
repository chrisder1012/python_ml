``COLR``: Color Table
---------------------

.. automodule:: fontTools.ttLib.tables.C_O_L_R_
   :inherited-members:
   :members:
   :undoc-members:
