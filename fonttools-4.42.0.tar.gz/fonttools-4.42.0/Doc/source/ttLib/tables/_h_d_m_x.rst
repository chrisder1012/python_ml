``hdmx``: Horizontal Device Metrics
-----------------------------------

.. automodule:: fontTools.ttLib.tables._h_d_m_x
   :inherited-members:
   :members:
   :undoc-members:

