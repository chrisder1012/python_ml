``gvar``:  Glyph Variations Table
---------------------------------

.. automodule:: fontTools.ttLib.tables._g_v_a_r
   :inherited-members:
   :members:
   :undoc-members:


TupleVariation
^^^^^^^^^^^^^^

.. automodule:: fontTools.ttLib.tables.TupleVariation
   :inherited-members:
   :members:
   :undoc-members:
