``EBLC``: Embedded Bitmap Location Table
----------------------------------------

.. automodule:: fontTools.ttLib.tables.E_B_L_C_
   :inherited-members:
   :members:
   :undoc-members:


BitmapGlyphMetrics
^^^^^^^^^^^^^^^^^^

.. automodule:: fontTools.ttLib.tables.BitmapGlyphMetrics
   :noindex:
   :inherited-members:
   :members:
   :undoc-members:

