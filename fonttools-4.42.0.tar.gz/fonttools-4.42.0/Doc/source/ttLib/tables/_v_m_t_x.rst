``vmtx``: Vertical Metrics Table
--------------------------------

.. automodule:: fontTools.ttLib.tables._v_m_t_x
   :inherited-members:
   :members:
   :undoc-members:

