``cvt``:  Control Value Table
-----------------------------

.. automodule:: fontTools.ttLib.tables._c_v_t
   :inherited-members:
   :members:
   :undoc-members:

