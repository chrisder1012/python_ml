``morx``: Extended Glyph Metamorphosis Table
--------------------------------------------

.. automodule:: fontTools.ttLib.tables._m_o_r_x
   :inherited-members:
   :members:
   :undoc-members:

