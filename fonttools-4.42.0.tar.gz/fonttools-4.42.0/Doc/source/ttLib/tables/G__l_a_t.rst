``Glat``: Graphite Glyph Attributes Table
-----------------------------------------

.. automodule:: fontTools.ttLib.tables.G__l_a_t
   :inherited-members:
   :members:
   :undoc-members:

