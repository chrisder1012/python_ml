``Gloc``: Graphite index to glyph attributes table
--------------------------------------------------

.. automodule:: fontTools.ttLib.tables.G__l_o_c
   :inherited-members:
   :members:
   :undoc-members:

