``opbd``: Optical Bounds Table
------------------------------

.. automodule:: fontTools.ttLib.tables._o_p_b_d
   :inherited-members:
   :members:
   :undoc-members:

