########
macUtils
########

.. automodule:: fontTools.ttLib.macUtils
   :inherited-members:
   :members:
   :undoc-members:
