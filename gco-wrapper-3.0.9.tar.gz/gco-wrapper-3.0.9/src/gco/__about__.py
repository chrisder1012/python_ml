__version__ = "3.0.9"
__version_info__ = tuple([int(i) for i in __version__.split(".")])

__all__ = ["__version__", "__version_info__"]
